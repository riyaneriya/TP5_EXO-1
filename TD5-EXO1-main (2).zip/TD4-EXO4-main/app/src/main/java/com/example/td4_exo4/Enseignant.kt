package com.example.td4_exo4

import java.io.Serializable

class Enseignant(_fname:String, _lname:String):Serializable {
    var fname=_fname
    var lname=_lname
}